# Kết quả thí nghiệm

| Ngày | Config | Commit | Môi trường | Val macro-F1 | Test macro-F1 | Thời gian train (phút) | Ghi chú |
|---|---|---|---|---|---|---|---|
| 2026-11-22 | `p11_caption_la_s1` | `f8f25ab` | server | 0.3862 | nan | 1.3 | plan phase11_image_contribution | peak VRAM 0.87 GB |
