| group | n | val macro-F1 | val weighted-F1 | val macro-F1 (bỏ text-sarcasm) |
|---|---|---|---|---|
| p11_caption_la | 3 | 0.3915 ± 0.0049 | 0.7493 ± 0.0110 | 0.5220 ± 0.0065 |
